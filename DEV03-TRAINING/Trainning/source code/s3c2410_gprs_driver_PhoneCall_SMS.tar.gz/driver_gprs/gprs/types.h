#ifndef _TYPES_H
	#define _TYPES_H

typedef unsigned char u8;
typedef          char  s8;
typedef unsigned short u16;
typedef          short s16;

#endif
